=== WordPress PyScripter ===
Contributors: technocannon
Donate link: https://technocannon.com/cashapp
Tags: pyscript, python, front-end development
Requires at least: 5.9.3
Tested up to: 5.9.3
Requires PHP: 7.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A WordPress plugin to enable the PyScript Web Development Framework.

== Description ==

The WordPress PyScripter plugin adds a link to the PyScript stylesheet and JavaScript source file to the head of your WordPress website and also deactivates the wptexturize functions to remove syntax errors resulting from modified quotation marks.

== Installation ==

1. Log in to your WordPress admin area.
2. Navigate to the "Plugins" sidebar menu section and click "Add New".
3. In the search field type, "WordPress PyScripter" and click "Search Plugins".
4. Once you've found the plugin, click the "Install Now" button.
5. After it installs, click on the "Activate Plugin" link.

or

1. Upload the plugin folder to your /wp-content/plugins/ folder.
2. Go to the **Plugins** page and activate the plugin.


== Frequently Asked Questions ==

= What is PyScript =

PyScript is a framework that allows users to create rich Python applications in the browser using HTML’s interface. PyScript aims to give users a first-class programming language that has consistent styling rules, is more expressive, and is easier to learn.

You can find out more about PyScript at: (https://pyscript.net/)

= How do I use the WordPress PyScripter plugin? =

Once activated, go to any page or post and enter Pythonic commands between the following PyScript tags as HTML content:

`<py-script> </py-script>`

For example, to print a "Hello World!" statement, you would enter the following as html content:
`<py-script> print('Hello World!') </py-script>`

= Why does WordPress PyScripter plugin? =

= How to uninstall the plugin? =
  
Simply deactivate and delete the plugin.


== Screenshots ==
1. Installation & Activation of WordPress PyScripter Plugin
2. PyScript Hello World Command Example
3. PyScript Hello World Command Results
4. Deactivate WordPress PyScripter Plugin
5. Delete WordPress PyScripter Plugin


== Changelog ==

= 1.0 =
*Released - May 4 2022*
